#     Copyright 2021. ThingsBoard
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.

"""Import libraries"""

import time
from random import choice
from string import ascii_lowercase
from threading import Thread
from typing import DefaultDict

# Import base class for connector and logger
from thingsboard_gateway.tb_utility.tb_utility import TBUtility
from thingsboard_gateway.connectors.connector import Connector, log
from thingsboard_gateway.tb_utility.tb_loader import TBModuleLoader

# Try import SMBus library or install it and import
try:
    import smbus
except ImportError:
    print("SMBus library not found - installing...")
    TBUtility.install_package('smbus')
    import smbus


class SerialI2CConnector(Thread, Connector):  # Define a connector class, it should inherit from "Connector" class.
    
    MCP23017_IODIRA = 0x00
    MCP23017_IPOLA  = 0x02
    MCP23017_GPINTENA = 0x04
    MCP23017_DEFVALA = 0x06
    MCP23017_INTCONA = 0x08
    MCP23017_IOCONA = 0x0A
    MCP23017_GPPUA = 0x0C
    MCP23017_INTFA = 0x0E
    MCP23017_INTCAPA = 0x10
    MCP23017_GPIOA = 0x12
    MCP23017_OLATA = 0x14

    MCP23017_IODIRB = 0x01
    MCP23017_IPOLB = 0x03
    MCP23017_GPINTENB = 0x05
    MCP23017_DEFVALB = 0x07
    MCP23017_INTCONB = 0x09
    MCP23017_IOCONB = 0x0B
    MCP23017_GPPUB = 0x0D
    MCP23017_INTFB = 0x0F
    MCP23017_INTCAPB = 0x11
    MCP23017_GPIOB = 0x13
    MCP23017_OLATB = 0x15

    MCP23017_ADDRESS = 0x27
    
    def __init__(self, gateway, config, connector_type):
        super().__init__()  # Initialize parents classes
        self.statistics = {'MessagesReceived': 0,
                           'MessagesSent': 0}  # Dictionary, will save information about count received and sent messages.
        self.__config = config  # Save configuration from the configuration file.
        self.__gateway = gateway  # Save gateway object, we will use some gateway methods for adding devices and saving data from them.
        self.setName(self.__config.get("name",
                                       "I2C %s connector " % self.get_name() + ''.join(
                                           choice(ascii_lowercase) for _ in range(5))))  # get from the configuration or create name for logs.
        log.info("Starting I2C %s connector", self.get_name())  # Send message to logger
        self.daemon = True  # Set self thread as daemon
        self.stopped = True  # Service variable for check state
        self.__connected = False  # Service variable for check connection to device
        self.__devices = {}  # Dictionary with devices, will contain devices configurations, converters for devices and serial port objects
        self.__load_converters(connector_type)  # Call function to load converters and save it into devices dictionary
        self.__connect_to_devices()  # Call function for connect to devices
        log.info('I2C connector %s initialization success.', self.get_name())  # Message to logger
        log.info("Devices in configuration file found: %s ", '\n'.join(device for device in self.__devices))  # Message to logger

    def __connect_to_devices(self):  # Function for opening connection and connecting to devices
        for device in self.__devices:
            try:  # Start error handler
                connection_start = time.time()
                if self.__devices[device].get("serial") is None \
                        or self.__devices[device]["serial"] is None:  # Connect only if serial not available earlier or it is closed.
                    self.__devices[device]["serial"] = None
                    while self.__devices[device]["serial"] is None:  # Try connect
                        # connection to serial port with parameters from configuration file or default
                        
                        try:
                            i2c_address = self.__devices[device]["device_config"].get("i2c_address", 1)
                            self.__devices[device]["serial"] = smbus.SMBus(i2c_address)

                            #   Addr(BIN)      Addr(hex)
                            #XXX X  A2 A1 A0
                            #010 0  1  1  1      0x27
                            #010 0  1  1  0      0x26 
                            #010 0  1  0  1      0x25 
                            #010 0  1  0  0      0x24 
                            #010 0  0  1  1      0x23 
                            #010 0  0  1  0      0x22
                            #010 0  0  0  1      0x21
                            #010 0  0  0  0      0x20

                            self.MCP23017_ADDRESS = self.__devices[device]["device_config"].get("MCP23017_address", "0x27")
                            self.MCP23017_ADDRESS = int(self.MCP23017_ADDRESS, 16)

                            #Configue the register to default value
                            for addr in range(22):
                                if (addr == 0) or (addr == 1):
                                    self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS, addr, 0xFF)
                                else:
                                    self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS, addr, 0x00)

                                
                            #configue all PinA output
                            self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS,self.MCP23017_IODIRA,0x00)
                                
                            #configue all PinB input
                            self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS,self.MCP23017_IODIRB,0xFF)
                            #configue all PinB pullUP
                            self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS,self.MCP23017_GPPUB,0xFF)
                        except Exception as e:
                            log.exception(e)

                        time.sleep(.1)
                        if time.time() - connection_start > 10:  # Break connection try if it setting up for 10 seconds
                            log.error("Connection refused per timeout for device %s", self.__devices[device]["device_config"].get("name"))
                            break
            except Exception as e:
                log.exception(e)
            else:  # if no exception handled - add device and change connection state
                # added handling of "|" (JL, 20211129)
                self.__gateway.add_device(self.__devices[device]["device_config"]["name"].split("|")[0], {"connector": self}, self.__devices[device]["device_config"]["type"])
                keys = ['attributes', 'telemetry']
                self.__devices[device]["latest_data"] = {}
                for key in keys:
                    self.__devices[device]["latest_data"][key] = DefaultDict(lambda: None)
                self.__connected = True

    def open(self):  # Function called by gateway on start
        self.stopped = False
        self.start()

    def get_name(self):  # Function used for logging, sending data and statistic
        return self.name

    def is_connected(self):  # Function for checking connection state
        return self.__connected

    def __load_converters(self, connector_type):  # Function for search a converter and save it.
        devices_config = self.__config.get('devices')
        try:
            if devices_config is not None:
                for device_config in devices_config:
                    if device_config.get('converter') is not None:
                        converter = TBModuleLoader.import_module(connector_type, device_config['converter'])
                        self.__devices[device_config['name']] = {'converter': converter(device_config),
                                                                 'device_config': device_config}
                    else:
                        log.error('Converter configuration for the I2C connector %s -- not found, please check your configuration file.', self.get_name())
            else:
                log.error('Section "devices" in the configuration not found. A I2C connector %s has being stopped.', self.get_name())
                self.close()
        except Exception as e:
            log.exception(e)

    def run(self):  # Main loop of thread
        try:
            while True:
                for device in self.__devices:
                    try:
                        #configue all PinA output low level
                        self.__devices[device]["serial"].write_byte_data(self.MCP23017_ADDRESS,self.MCP23017_GPIOA,0x00)
                        #then PinB read the level from PinA, print 0 means all PinA are in low level
                        data_from_device = self.__devices[device]["serial"].read_byte_data(self.MCP23017_ADDRESS,self.MCP23017_GPIOB)
                        latest_data = self.__devices[device]["latest_data"]
                        converted_data, self.__devices[device]["latest_data"] = self.__devices[device]['converter'].convert(self.__devices[device]['device_config'], data_from_device, latest_data)
                        if len(converted_data['attributes']) > 0 or len(converted_data['telemetry']) > 0 :
                            self.__gateway.send_to_storage(self.get_name(), converted_data)
                        time.sleep(0.5)
                    except Exception as e:
                        log.exception(e)
                        self.close()
                        raise e 
                if not self.__connected:
                    break
        except Exception as e:
            log.exception(e)

    def close(self):  # Close connect function, usually used if exception handled in gateway main loop or in connector main loop
        self.stopped = True
        for device in self.__devices:
            self.__gateway.del_device(self.__devices[device])
            if self.__devices[device]['serial'].isOpen():
                self.__devices[device]['serial'].close()

    def on_attributes_update(self, content):  # Function used for processing attribute update requests from ThingsBoard
        pass

    def server_side_rpc_handler(self, content):
        pass

#     Copyright 2021. ThingsBoard
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.

from thingsboard_gateway.connectors.converter import Converter, log


class I2CUplinkConverter(Converter):
    def __init__(self, config):
        self.__config = config
        # Added handling of "|" in device name (JL, 20211129)
        dev_name = config.get('name', 'CustomI2CDevice').split("|")[0]
        self.result_dict = {
            'deviceName': dev_name,
            'deviceType': config.get('deviceType', 'default'),
            'attributes': [],
            'telemetry': []
            }

    def convert(self, config, data: bytes, latest_data):
        sections = ['attributes', 'telemetry']
        for section in sections:
            self.result_dict[section] = []
            data_to_convert = data
            totalPos = 0
            if self.__config.get('totalpos') is not None:
                totalPos = self.__config.get('totalpos')
            if self.__config.get(section) is not None:
                bin_data = bin(data_to_convert)
                str_data = str(bin_data)[2:]
                str_data = str_data.zfill(totalPos)
                for config_object in self.__config.get(section):
                    if config_object.get('position') is not None:
                        position = config_object.get('position')
                        data_to_convert = str_data[position]
                        converted_data = {config_object['key']: data_to_convert}
                        if latest_data[section][config_object['key']] != data_to_convert:
                            self.result_dict[section].append(converted_data)
                            latest_data[section][config_object['key']] = data_to_convert
                            # log.debug("Latest data: ")
                            # log.debug(latest_data)
                        # log.debug(self.result_dict)
        #log.debug(self.result_dict)
        log.debug("Converted data: %s", self.result_dict)
        return self.result_dict, latest_data
